package oop.classes.enums;

public enum ApprovalStatus {
    PENDING, 
    APPROVED, 
    DENIED, 
    PENDING_HR, 
    PENDING_SUPERVISOR;
}